# WebProject
Just a Website to show Details from a Database



On running the above website to upload a Folder named "Upload" is to be created for usage.
